package com.tabagent.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.tabagent.ui.screens.*
import com.tabagent.util.SecurePrefs
import dagger.hilt.android.AndroidEntryPoint
import java.net.URLDecoder
import java.net.URLEncoder
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var securePrefs: SecurePrefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val settings = remember { securePrefs.getSettings() }
            val isDark = when (settings.theme) {
                com.tabagent.model.AppTheme.DARK -> true
                com.tabagent.model.AppTheme.LIGHT -> false
                com.tabagent.model.AppTheme.SYSTEM -> isSystemInDarkTheme()
            }

            MaterialTheme(
                colorScheme = if (isDark) darkColorScheme(
                    primary = Color(0xFF4FC3F7),
                    secondary = Color(0xFF80CBC4),
                    tertiary = Color(0xFFCE93D8),
                    background = Color(0xFF0D0D0D),
                    surface = Color(0xFF1A1A1A),
                    surfaceVariant = Color(0xFF1E2A3A)
                ) else lightColorScheme()
            ) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    TabAgentNavHost()
                }
            }
        }
    }
}

@Composable
fun TabAgentNavHost() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "chat"
    ) {
        composable("chat") {
            ChatScreen(
                onOpenSettings = { navController.navigate("settings") },
                onOpenFileBrowser = { navController.navigate("files") },
                onOpenTerminal = { navController.navigate("terminal") }
            )
        }

        composable("settings") {
            SettingsScreen(onBack = { navController.popBackStack() })
        }

        composable("files") {
            FileBrowserScreen(
                onFileOpen = { path ->
                    val encoded = URLEncoder.encode(path, "UTF-8")
                    navController.navigate("editor/$encoded")
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable("terminal") {
            TerminalScreen(onBack = { navController.popBackStack() })
        }

        composable(
            "editor/{path}",
            arguments = listOf(navArgument("path") { type = NavType.StringType })
        ) { backStackEntry ->
            val path = URLDecoder.decode(
                backStackEntry.arguments?.getString("path") ?: "",
                "UTF-8"
            )
            EditorScreen(
                filePath = path,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
