package com.tabagent

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class TabAgentApp : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            // Agent running channel
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_AGENT,
                    "AI Agent",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Shows when AI agent is running"
                }
            )

            // Terminal channel
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_TERMINAL,
                    "Terminal",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Terminal session notifications"
                }
            )

            // General channel
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_GENERAL,
                    "General",
                    NotificationManager.IMPORTANCE_DEFAULT
                )
            )
        }
    }

    companion object {
        const val CHANNEL_AGENT = "agent_channel"
        const val CHANNEL_TERMINAL = "terminal_channel"
        const val CHANNEL_GENERAL = "general_channel"
    }
}
