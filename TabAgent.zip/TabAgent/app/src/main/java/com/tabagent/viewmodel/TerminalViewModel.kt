package com.tabagent.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tabagent.ui.screens.LineType
import com.tabagent.ui.screens.TerminalLine
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.*
import javax.inject.Inject

@HiltViewModel
class TerminalViewModel @Inject constructor(
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val _outputLines = MutableStateFlow<List<TerminalLine>>(emptyList())
    val outputLines: StateFlow<List<TerminalLine>> = _outputLines.asStateFlow()

    private val _currentDir = MutableStateFlow(context.filesDir.absolutePath)
    val currentDir: StateFlow<String> = _currentDir.asStateFlow()

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private val _commandHistory = MutableStateFlow<List<String>>(emptyList())
    val commandHistory: StateFlow<List<String>> = _commandHistory.asStateFlow()

    private var currentProcess: Process? = null

    init {
        addLine("TabAgent Terminal — Android Shell", LineType.SYSTEM)
        addLine("Working directory: ${context.filesDir.absolutePath}", LineType.SYSTEM)
        addLine("", LineType.OUTPUT)
    }

    fun executeCommand(command: String) {
        // Add to history
        _commandHistory.update { listOf(command) + it.take(99) }
        addLine("$ $command", LineType.COMMAND)

        // Handle built-in commands
        when {
            command == "clear" || command == "cls" -> {
                clearScreen()
                return
            }
            command.startsWith("cd ") -> {
                val target = command.removePrefix("cd ").trim()
                val newDir = when {
                    target == ".." -> File(_currentDir.value).parentFile?.absolutePath ?: _currentDir.value
                    target.startsWith("/") -> target
                    else -> "${_currentDir.value}/$target"
                }
                if (File(newDir).isDirectory) {
                    _currentDir.value = newDir
                    addLine("", LineType.OUTPUT)
                } else {
                    addLine("cd: $target: No such directory", LineType.ERROR)
                }
                return
            }
            command == "pwd" -> {
                addLine(_currentDir.value, LineType.OUTPUT)
                return
            }
        }

        viewModelScope.launch(Dispatchers.IO) {
            _isRunning.value = true
            try {
                val process = ProcessBuilder("/bin/sh", "-c", command)
                    .directory(File(_currentDir.value))
                    .redirectErrorStream(true)
                    .start()

                currentProcess = process

                val reader = BufferedReader(InputStreamReader(process.inputStream))
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    addLine(line ?: "", LineType.OUTPUT)
                }

                val exitCode = process.waitFor()
                if (exitCode != 0) {
                    addLine("[Exit $exitCode]", LineType.ERROR)
                }
            } catch (e: Exception) {
                addLine("Error: ${e.message}", LineType.ERROR)
            } finally {
                _isRunning.value = false
                currentProcess = null
                addLine("", LineType.OUTPUT)
            }
        }
    }

    fun killCurrentProcess() {
        currentProcess?.destroy()
        addLine("^C", LineType.ERROR)
        _isRunning.value = false
    }

    fun clearScreen() {
        _outputLines.value = emptyList()
    }

    private fun addLine(text: String, type: LineType) {
        _outputLines.update { lines ->
            (lines + TerminalLine(text, type)).takeLast(5000) // limit buffer
        }
    }
}
