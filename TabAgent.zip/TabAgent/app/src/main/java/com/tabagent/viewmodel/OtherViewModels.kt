package com.tabagent.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tabagent.model.*
import com.tabagent.util.SecurePrefs
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

// ─── Settings ViewModel ───────────────────────────────────────────────────────

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val securePrefs: SecurePrefs
) : ViewModel() {

    private val _apiConfig = MutableStateFlow(securePrefs.getApiConfig())
    val apiConfig: StateFlow<ApiConfig> = _apiConfig.asStateFlow()

    private val _appSettings = MutableStateFlow(securePrefs.getSettings())
    val appSettings: StateFlow<AppSettings> = _appSettings.asStateFlow()

    fun saveApiConfig(config: ApiConfig) {
        securePrefs.saveApiConfig(config)
        _apiConfig.value = config
    }

    fun saveSettings(settings: AppSettings) {
        securePrefs.saveSettings(settings)
        _appSettings.value = settings
    }
}

// ─── File Browser ViewModel ───────────────────────────────────────────────────

@HiltViewModel
class FileBrowserViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val securePrefs: SecurePrefs
) : ViewModel() {

    private val _currentPath = MutableStateFlow(context.filesDir.absolutePath)
    val currentPath: StateFlow<String> = _currentPath.asStateFlow()

    private val _files = MutableStateFlow<List<FileNode>>(emptyList())
    val files: StateFlow<List<FileNode>> = _files.asStateFlow()

    private val _selectedFile = MutableStateFlow<FileNode?>(null)
    val selectedFile: StateFlow<FileNode?> = _selectedFile.asStateFlow()

    private val rootPath = context.filesDir.absolutePath

    init {
        loadFiles()
    }

    fun navigate(path: String) {
        _currentPath.value = path
        _selectedFile.value = null
        loadFiles()
        securePrefs.saveLastProject(path)
    }

    fun navigateUp(): Boolean {
        val parent = File(_currentPath.value).parentFile
        return if (parent != null && parent.absolutePath.startsWith(rootPath)) {
            navigate(parent.absolutePath)
            true
        } else false
    }

    fun canGoUp(): Boolean {
        val parent = File(_currentPath.value).parentFile
        return parent != null && parent.absolutePath.startsWith(rootPath)
    }

    fun selectFile(file: FileNode?) {
        _selectedFile.value = file
    }

    fun refresh() = loadFiles()

    fun createFile(name: String) {
        val file = File(_currentPath.value, name)
        file.parentFile?.mkdirs()
        file.createNewFile()
        loadFiles()
    }

    fun createFolder(name: String) {
        File(_currentPath.value, name).mkdirs()
        loadFiles()
    }

    fun deleteItem(node: FileNode) {
        File(node.path).deleteRecursively()
        loadFiles()
    }

    private fun loadFiles() {
        viewModelScope.launch {
            val dir = File(_currentPath.value)
            if (!dir.exists()) {
                dir.mkdirs()
            }
            _files.value = dir.listFiles()
                ?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
                ?.map { file ->
                    FileNode(
                        name = file.name,
                        path = file.absolutePath,
                        isDirectory = file.isDirectory,
                        size = file.length(),
                        lastModified = file.lastModified()
                    )
                } ?: emptyList()
        }
    }
}
