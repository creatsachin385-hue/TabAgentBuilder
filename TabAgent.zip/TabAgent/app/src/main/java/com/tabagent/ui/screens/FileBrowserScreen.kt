package com.tabagent.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.tabagent.model.FileNode
import com.tabagent.viewmodel.FileBrowserViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileBrowserScreen(
    viewModel: FileBrowserViewModel = hiltViewModel(),
    onFileOpen: (String) -> Unit,
    onBack: () -> Unit
) {
    val currentPath by viewModel.currentPath.collectAsState()
    val files by viewModel.files.collectAsState()
    val selectedFile by viewModel.selectedFile.collectAsState()
    var showNewFileDialog by remember { mutableStateOf(false) }
    var showNewFolderDialog by remember { mutableStateOf(false) }
    var newItemName by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        currentPath.split("/").lastOrNull() ?: "Files",
                        style = MaterialTheme.typography.titleMedium
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {
                        if (!viewModel.navigateUp()) onBack()
                    }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showNewFileDialog = true }) {
                        Icon(Icons.Default.NoteAdd, contentDescription = "New File")
                    }
                    IconButton(onClick = { showNewFolderDialog = true }) {
                        Icon(Icons.Default.CreateNewFolder, contentDescription = "New Folder")
                    }
                    IconButton(onClick = { viewModel.refresh() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                }
            )
        }
    ) { padding ->
        Row(modifier = Modifier.padding(padding).fillMaxSize()) {
            // File list
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(8.dp)
            ) {
                // Parent directory
                if (viewModel.canGoUp()) {
                    item {
                        FileListItem(
                            icon = Icons.Default.ArrowUpward,
                            name = "..",
                            isDirectory = true,
                            onClick = { viewModel.navigateUp() }
                        )
                    }
                }

                items(files) { file ->
                    FileListItem(
                        icon = if (file.isDirectory) Icons.Default.Folder
                               else getFileIcon(file.name),
                        name = file.name,
                        isDirectory = file.isDirectory,
                        size = if (!file.isDirectory) formatSize(file.size) else null,
                        isSelected = selectedFile?.path == file.path,
                        onClick = {
                            if (file.isDirectory) {
                                viewModel.navigate(file.path)
                            } else {
                                viewModel.selectFile(file)
                            }
                        },
                        onLongClick = {
                            // Context menu: delete, rename
                        }
                    )
                }
            }

            // File preview panel (tablet)
            selectedFile?.let { file ->
                if (!file.isDirectory) {
                    VerticalDivider()
                    FilePreviewPanel(
                        filePath = file.path,
                        onOpen = { onFileOpen(file.path) },
                        onClose = { viewModel.selectFile(null) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }

    // New file dialog
    if (showNewFileDialog) {
        AlertDialog(
            onDismissRequest = { showNewFileDialog = false },
            title = { Text("New File") },
            text = {
                OutlinedTextField(
                    value = newItemName,
                    onValueChange = { newItemName = it },
                    label = { Text("File name") },
                    placeholder = { Text("main.py") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newItemName.isNotBlank()) {
                        viewModel.createFile(newItemName)
                        newItemName = ""
                        showNewFileDialog = false
                    }
                }) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showNewFileDialog = false; newItemName = "" }) {
                    Text("Cancel")
                }
            }
        )
    }

    // New folder dialog
    if (showNewFolderDialog) {
        AlertDialog(
            onDismissRequest = { showNewFolderDialog = false },
            title = { Text("New Folder") },
            text = {
                OutlinedTextField(
                    value = newItemName,
                    onValueChange = { newItemName = it },
                    label = { Text("Folder name") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newItemName.isNotBlank()) {
                        viewModel.createFolder(newItemName)
                        newItemName = ""
                        showNewFolderDialog = false
                    }
                }) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showNewFolderDialog = false; newItemName = "" }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileListItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    name: String,
    isDirectory: Boolean,
    size: String? = null,
    isSelected: Boolean = false,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null
) {
    Surface(
        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.surface,
        shape = MaterialTheme.shapes.small,
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = if (isDirectory) MaterialTheme.colorScheme.primary
                       else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(12.dp))
            Text(
                name,
                style = MaterialTheme.typography.bodyMedium,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.weight(1f)
            )
            size?.let {
                Text(it,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (isDirectory) {
                Icon(Icons.Default.ChevronRight, contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun FilePreviewPanel(
    filePath: String,
    onOpen: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val content = remember(filePath) {
        try { File(filePath).readText().take(5000) } catch (e: Exception) { "Cannot preview: ${e.message}" }
    }

    Column(modifier = modifier.fillMaxHeight()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(filePath.split("/").last(),
                style = MaterialTheme.typography.titleSmall)
            Row {
                TextButton(onClick = onOpen) { Text("Open") }
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Close preview")
                }
            }
        }
        HorizontalDivider()
        androidx.compose.foundation.text.selection.SelectionContainer {
            androidx.compose.foundation.lazy.LazyColumn(
                modifier = Modifier.weight(1f).padding(8.dp)
            ) {
                item {
                    Text(
                        content,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

fun getFileIcon(name: String) = when (name.substringAfterLast(".").lowercase()) {
    "py" -> Icons.Default.Code
    "kt", "java" -> Icons.Default.Code
    "js", "ts" -> Icons.Default.Javascript
    "html", "xml" -> Icons.Default.Html
    "json" -> Icons.Default.DataObject
    "md", "txt" -> Icons.Default.Description
    "png", "jpg", "jpeg", "gif" -> Icons.Default.Image
    "sh", "bash" -> Icons.Default.Terminal
    else -> Icons.Default.InsertDriveFile
}

fun formatSize(bytes: Long): String = when {
    bytes > 1_000_000 -> "${"%.1f".format(bytes / 1_000_000.0)}MB"
    bytes > 1_000 -> "${"%.1f".format(bytes / 1_000.0)}KB"
    else -> "${bytes}B"
}
