package com.tabagent.model

import androidx.room.*
import kotlinx.coroutines.flow.Flow

// ─── AI Provider Config ─────────────────────────────────────────────────────

enum class ApiProvider(val displayName: String, val baseUrl: String) {
    ANTHROPIC("Anthropic (Claude)", "https://api.anthropic.com"),
    OPENAI("OpenAI (GPT)", "https://api.openai.com"),
    GROQ("Groq (Fast)", "https://api.groq.com/openai"),
    OPENROUTER("OpenRouter", "https://openrouter.ai/api"),
    CUSTOM("Custom / Local", "")
}

data class ApiConfig(
    val provider: ApiProvider = ApiProvider.ANTHROPIC,
    val apiKey: String = "",
    val model: String = "claude-sonnet-4-6",
    val baseUrl: String = "",
    val maxTokens: Int = 8096,
    val temperature: Float = 0.7f,
    val systemPrompt: String = DEFAULT_SYSTEM_PROMPT
)

// ─── Chat / Session Models ───────────────────────────────────────────────────

enum class MessageRole { USER, ASSISTANT, SYSTEM, TOOL }
enum class MessageStatus { SENDING, STREAMING, DONE, ERROR }

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val role: MessageRole,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: MessageStatus = MessageStatus.DONE,
    val tokenCount: Int = 0,
    val toolName: String? = null,
    val toolInput: String? = null,
    val toolResult: String? = null,
    val thinkingContent: String? = null
)

@Entity(tableName = "sessions")
data class Session(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val title: String = "New Session",
    val projectPath: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val messageCount: Int = 0,
    val totalTokens: Int = 0
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val sessionId: String,
    val role: String,
    val content: String,
    val timestamp: Long,
    val tokenCount: Int = 0
)

// ─── Project Models ──────────────────────────────────────────────────────────

@Entity(tableName = "projects")
data class Project(
    @PrimaryKey val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val path: String,
    val description: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val lastOpenedAt: Long = System.currentTimeMillis(),
    val language: String = "auto",
    val agentsFile: String? = null
)

data class FileNode(
    val name: String,
    val path: String,
    val isDirectory: Boolean,
    val size: Long = 0,
    val lastModified: Long = 0,
    val children: List<FileNode> = emptyList(),
    var isExpanded: Boolean = false
)

// ─── Diff / Checkpoint Models ────────────────────────────────────────────────

data class FileDiff(
    val filePath: String,
    val oldContent: String,
    val newContent: String,
    val hunks: List<DiffHunk> = emptyList()
)

data class DiffHunk(
    val oldStart: Int,
    val oldCount: Int,
    val newStart: Int,
    val newCount: Int,
    val lines: List<DiffLine>
)

data class DiffLine(
    val type: DiffLineType,
    val content: String,
    val lineNumber: Int
)

enum class DiffLineType { ADDED, REMOVED, CONTEXT }

data class Checkpoint(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sessionId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val description: String,
    val diffs: List<FileDiff>
)

// ─── Tool Models ─────────────────────────────────────────────────────────────

data class ToolCall(
    val id: String,
    val name: String,
    val input: Map<String, Any>,
    val result: String? = null,
    val isLoading: Boolean = true
)

// ─── Settings ────────────────────────────────────────────────────────────────

data class AppSettings(
    val theme: AppTheme = AppTheme.DARK,
    val fontSize: Int = 14,
    val tabSize: Int = 2,
    val wordWrap: Boolean = true,
    val showLineNumbers: Boolean = true,
    val autoSave: Boolean = true,
    val streamingEnabled: Boolean = true,
    val showTokenCount: Boolean = true,
    val showThinking: Boolean = false,
    val hapticFeedback: Boolean = true
)

enum class AppTheme { LIGHT, DARK, SYSTEM }

// ─── Constants ───────────────────────────────────────────────────────────────

const val DEFAULT_SYSTEM_PROMPT = """You are an expert AI coding assistant running on a mobile device. You have access to:
- read_file: Read file contents
- write_file: Write/create files  
- execute_command: Run shell commands in the Linux environment
- list_directory: List files and folders
- search_files: Search for text in files
- web_fetch: Fetch web content

Work autonomously to complete coding tasks. Always explain what you're doing.
When writing code, write complete, working implementations.
After making changes, verify they work by running relevant commands."""
