package com.tabagent.util

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.tabagent.model.ApiConfig
import com.tabagent.model.ApiProvider
import com.tabagent.model.AppSettings
import com.tabagent.model.AppTheme
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SecurePrefs @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    // Encrypted prefs for API keys
    private val securePrefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "tab_agent_secure",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    // Regular prefs for non-sensitive settings
    private val prefs: SharedPreferences =
        context.getSharedPreferences("tab_agent_prefs", Context.MODE_PRIVATE)

    // ─── API Config ───────────────────────────────────────────────────────────

    fun saveApiConfig(config: ApiConfig) {
        securePrefs.edit().apply {
            putString(KEY_API_KEY, config.apiKey)
            putString(KEY_PROVIDER, config.provider.name)
            putString(KEY_MODEL, config.model)
            putString(KEY_BASE_URL, config.baseUrl)
            putInt(KEY_MAX_TOKENS, config.maxTokens)
            putFloat(KEY_TEMPERATURE, config.temperature)
            putString(KEY_SYSTEM_PROMPT, config.systemPrompt)
            apply()
        }
    }

    fun getApiConfig(): ApiConfig {
        val providerName = securePrefs.getString(KEY_PROVIDER, ApiProvider.ANTHROPIC.name)
        val provider = try {
            ApiProvider.valueOf(providerName ?: ApiProvider.ANTHROPIC.name)
        } catch (_: Exception) {
            ApiProvider.ANTHROPIC
        }

        return ApiConfig(
            provider = provider,
            apiKey = securePrefs.getString(KEY_API_KEY, "") ?: "",
            model = securePrefs.getString(KEY_MODEL, getDefaultModel(provider)) ?: getDefaultModel(provider),
            baseUrl = securePrefs.getString(KEY_BASE_URL, provider.baseUrl) ?: provider.baseUrl,
            maxTokens = securePrefs.getInt(KEY_MAX_TOKENS, 8096),
            temperature = securePrefs.getFloat(KEY_TEMPERATURE, 0.7f),
            systemPrompt = securePrefs.getString(KEY_SYSTEM_PROMPT, com.tabagent.model.DEFAULT_SYSTEM_PROMPT) ?: com.tabagent.model.DEFAULT_SYSTEM_PROMPT
        )
    }

    fun hasApiKey(): Boolean = securePrefs.getString(KEY_API_KEY, "")?.isNotBlank() == true

    // ─── App Settings ─────────────────────────────────────────────────────────

    fun saveSettings(settings: AppSettings) {
        prefs.edit().apply {
            putString(KEY_THEME, settings.theme.name)
            putInt(KEY_FONT_SIZE, settings.fontSize)
            putInt(KEY_TAB_SIZE, settings.tabSize)
            putBoolean(KEY_WORD_WRAP, settings.wordWrap)
            putBoolean(KEY_LINE_NUMBERS, settings.showLineNumbers)
            putBoolean(KEY_AUTO_SAVE, settings.autoSave)
            putBoolean(KEY_STREAMING, settings.streamingEnabled)
            putBoolean(KEY_SHOW_TOKENS, settings.showTokenCount)
            putBoolean(KEY_SHOW_THINKING, settings.showThinking)
            putBoolean(KEY_HAPTIC, settings.hapticFeedback)
            apply()
        }
    }

    fun getSettings(): AppSettings {
        return AppSettings(
            theme = AppTheme.valueOf(prefs.getString(KEY_THEME, AppTheme.DARK.name) ?: AppTheme.DARK.name),
            fontSize = prefs.getInt(KEY_FONT_SIZE, 14),
            tabSize = prefs.getInt(KEY_TAB_SIZE, 2),
            wordWrap = prefs.getBoolean(KEY_WORD_WRAP, true),
            showLineNumbers = prefs.getBoolean(KEY_LINE_NUMBERS, true),
            autoSave = prefs.getBoolean(KEY_AUTO_SAVE, true),
            streamingEnabled = prefs.getBoolean(KEY_STREAMING, true),
            showTokenCount = prefs.getBoolean(KEY_SHOW_TOKENS, true),
            showThinking = prefs.getBoolean(KEY_SHOW_THINKING, false),
            hapticFeedback = prefs.getBoolean(KEY_HAPTIC, true)
        )
    }

    // ─── Project History ──────────────────────────────────────────────────────

    fun saveLastProject(path: String) {
        prefs.edit().putString(KEY_LAST_PROJECT, path).apply()
    }

    fun getLastProject(): String? = prefs.getString(KEY_LAST_PROJECT, null)

    private fun getDefaultModel(provider: ApiProvider): String = when (provider) {
        ApiProvider.ANTHROPIC -> "claude-sonnet-4-6"
        ApiProvider.OPENAI -> "gpt-4o"
        ApiProvider.GROQ -> "llama-3.3-70b-versatile"
        ApiProvider.OPENROUTER -> "anthropic/claude-sonnet-4-6"
        ApiProvider.CUSTOM -> "local-model"
    }

    companion object {
        private const val KEY_API_KEY = "api_key"
        private const val KEY_PROVIDER = "provider"
        private const val KEY_MODEL = "model"
        private const val KEY_BASE_URL = "base_url"
        private const val KEY_MAX_TOKENS = "max_tokens"
        private const val KEY_TEMPERATURE = "temperature"
        private const val KEY_SYSTEM_PROMPT = "system_prompt"
        private const val KEY_THEME = "theme"
        private const val KEY_FONT_SIZE = "font_size"
        private const val KEY_TAB_SIZE = "tab_size"
        private const val KEY_WORD_WRAP = "word_wrap"
        private const val KEY_LINE_NUMBERS = "line_numbers"
        private const val KEY_AUTO_SAVE = "auto_save"
        private const val KEY_STREAMING = "streaming"
        private const val KEY_SHOW_TOKENS = "show_tokens"
        private const val KEY_SHOW_THINKING = "show_thinking"
        private const val KEY_HAPTIC = "haptic"
        private const val KEY_LAST_PROJECT = "last_project"
    }
}
