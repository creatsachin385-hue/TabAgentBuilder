package com.tabagent.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tabagent.agent.AgentExecutor
import com.tabagent.model.*
import com.tabagent.network.*
import com.tabagent.util.SecurePrefs
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val isLoading: Boolean = false,
    val streamingContent: String = "",
    val thinkingContent: String = "",
    val isStreaming: Boolean = false,
    val activeToolCall: ToolCall? = null,
    val error: String? = null,
    val totalTokens: Int = 0,
    val currentSession: Session? = null
)

@HiltViewModel
class ChatViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val agentExecutor: AgentExecutor,
    private val securePrefs: SecurePrefs
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private val _messages = mutableListOf<ChatMessage>()

    private var apiClient: AiApiClient? = null
    private var currentConfig: ApiConfig? = null

    init {
        loadConfig()
    }

    fun loadConfig() {
        val config = securePrefs.getApiConfig()
        currentConfig = config
        apiClient = AiApiClient(config)
    }

    fun sendMessage(userInput: String) {
        if (userInput.isBlank() || _uiState.value.isLoading) return

        val userMessage = ChatMessage(
            role = MessageRole.USER,
            content = userInput
        )
        _messages.add(userMessage)
        updateMessages()

        viewModelScope.launch {
            runAgentLoop()
        }
    }

    private suspend fun runAgentLoop() {
        val client = apiClient ?: run {
            setError("No API config. Go to Settings and add your API key.")
            return
        }

        _uiState.update { it.copy(isLoading = true, error = null) }

        var continueLoop = true
        var iterations = 0
        val maxIterations = 20 // prevent infinite loops

        while (continueLoop && iterations < maxIterations) {
            iterations++
            continueLoop = false

            var assistantContent = StringBuilder()
            var pendingToolUse: StreamEvent.ToolUse? = null

            _uiState.update { it.copy(isStreaming = true, streamingContent = "") }

            client.streamResponse(_messages, agentExecutor.tools).collect { event ->
                when (event) {
                    is StreamEvent.Token -> {
                        assistantContent.append(event.text)
                        _uiState.update {
                            it.copy(streamingContent = assistantContent.toString())
                        }
                    }
                    is StreamEvent.Thinking -> {
                        _uiState.update { it.copy(thinkingContent = event.text) }
                    }
                    is StreamEvent.ToolUse -> {
                        pendingToolUse = event
                        _uiState.update {
                            it.copy(
                                activeToolCall = ToolCall(
                                    id = event.id,
                                    name = event.name,
                                    input = emptyMap(),
                                    isLoading = true
                                )
                            )
                        }
                    }
                    is StreamEvent.Done -> {
                        // Finalize assistant message
                        if (assistantContent.isNotEmpty()) {
                            val assistantMsg = ChatMessage(
                                role = MessageRole.ASSISTANT,
                                content = assistantContent.toString()
                            )
                            _messages.add(assistantMsg)
                            updateMessages()
                        }

                        // Execute tool if pending
                        pendingToolUse?.let { toolUse ->
                            val result = agentExecutor.executeTool(toolUse.name, toolUse.input)

                            // Add tool result as user message (for context)
                            val toolResultMsg = ChatMessage(
                                role = MessageRole.TOOL,
                                content = result,
                                toolName = toolUse.name,
                                toolResult = result
                            )
                            _messages.add(toolResultMsg)
                            updateMessages()

                            _uiState.update { it.copy(activeToolCall = null) }

                            // Continue the loop so agent can respond to tool result
                            continueLoop = true
                        }
                    }
                    is StreamEvent.Error -> {
                        setError(event.message)
                    }
                    else -> {}
                }
            }

            _uiState.update {
                it.copy(
                    isStreaming = false,
                    streamingContent = "",
                    thinkingContent = ""
                )
            }
        }

        _uiState.update { it.copy(isLoading = false) }
    }

    fun clearMessages() {
        _messages.clear()
        _uiState.update {
            it.copy(messages = emptyList(), totalTokens = 0, error = null)
        }
    }

    fun retryLastMessage() {
        // Remove last assistant message and retry
        val lastUser = _messages.indexOfLast { it.role == MessageRole.USER }
        if (lastUser >= 0) {
            while (_messages.size > lastUser + 1) {
                _messages.removeAt(_messages.size - 1)
            }
            updateMessages()
            viewModelScope.launch { runAgentLoop() }
        }
    }

    fun stopGeneration() {
        // Stop is handled by cancelling the coroutine job
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = false, isStreaming = false) }
        }
    }

    fun setProjectRoot(path: String) {
        agentExecutor.setProjectRoot(path)
        // Inject project context into system
        val systemInfo = ChatMessage(
            role = MessageRole.SYSTEM,
            content = "Project root: $path"
        )
        // Update config system prompt
    }

    private fun setError(message: String) {
        _uiState.update { it.copy(error = message, isLoading = false, isStreaming = false) }
    }

    private fun updateMessages() {
        _uiState.update { it.copy(messages = _messages.toList()) }
    }
}
