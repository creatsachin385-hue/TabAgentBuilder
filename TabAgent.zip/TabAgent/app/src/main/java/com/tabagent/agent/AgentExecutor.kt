package com.tabagent.agent

import android.content.Context
import com.tabagent.model.*
import com.tabagent.network.*
import com.tabagent.terminal.TerminalSession
import com.google.gson.Gson
import com.google.gson.JsonParser
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AgentExecutor @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val gson = Gson()
    private var terminalSession: TerminalSession? = null
    private var projectRoot: String = context.filesDir.absolutePath

    // All available tools
    val tools = listOf(
        ToolDefinition(
            name = "read_file",
            description = "Read the contents of a file at the given path",
            parameters = listOf(
                ToolParameter("path", "string", "Absolute or relative file path")
            )
        ),
        ToolDefinition(
            name = "write_file",
            description = "Write content to a file, creating it if it doesn't exist",
            parameters = listOf(
                ToolParameter("path", "string", "File path to write to"),
                ToolParameter("content", "string", "Content to write")
            )
        ),
        ToolDefinition(
            name = "execute_command",
            description = "Execute a shell command in the Linux environment and return output",
            parameters = listOf(
                ToolParameter("command", "string", "Shell command to execute"),
                ToolParameter("timeout", "number", "Timeout in seconds (default 30)", required = false)
            )
        ),
        ToolDefinition(
            name = "list_directory",
            description = "List files and directories at the given path",
            parameters = listOf(
                ToolParameter("path", "string", "Directory path to list"),
                ToolParameter("recursive", "boolean", "List recursively", required = false)
            )
        ),
        ToolDefinition(
            name = "search_files",
            description = "Search for text pattern in files within a directory",
            parameters = listOf(
                ToolParameter("pattern", "string", "Text or regex to search for"),
                ToolParameter("directory", "string", "Directory to search in"),
                ToolParameter("file_pattern", "string", "File glob pattern like *.kt", required = false)
            )
        ),
        ToolDefinition(
            name = "delete_file",
            description = "Delete a file or empty directory",
            parameters = listOf(
                ToolParameter("path", "string", "Path to delete")
            )
        ),
        ToolDefinition(
            name = "create_directory",
            description = "Create a directory and all parent directories",
            parameters = listOf(
                ToolParameter("path", "string", "Directory path to create")
            )
        ),
        ToolDefinition(
            name = "move_file",
            description = "Move or rename a file",
            parameters = listOf(
                ToolParameter("source", "string", "Source path"),
                ToolParameter("destination", "string", "Destination path")
            )
        ),
        ToolDefinition(
            name = "web_fetch",
            description = "Fetch content from a URL",
            parameters = listOf(
                ToolParameter("url", "string", "URL to fetch"),
                ToolParameter("extract_text", "boolean", "Extract only text content", required = false)
            )
        ),
        ToolDefinition(
            name = "find_replace",
            description = "Find and replace text in a file",
            parameters = listOf(
                ToolParameter("path", "string", "File path"),
                ToolParameter("find", "string", "Text to find"),
                ToolParameter("replace", "string", "Replacement text")
            )
        )
    )

    fun setProjectRoot(path: String) {
        projectRoot = path
    }

    fun setTerminalSession(session: TerminalSession) {
        terminalSession = session
    }

    // Execute a tool call and return result
    suspend fun executeTool(name: String, inputJson: String): String {
        return try {
            val input = JsonParser.parseString(inputJson).asJsonObject

            when (name) {
                "read_file" -> {
                    val path = resolvePath(input.get("path").asString)
                    val file = File(path)
                    if (!file.exists()) "Error: File not found: $path"
                    else if (file.length() > 1_000_000) "Error: File too large (>1MB). Use search_files instead."
                    else file.readText()
                }

                "write_file" -> {
                    val path = resolvePath(input.get("path").asString)
                    val content = input.get("content").asString
                    val file = File(path)
                    file.parentFile?.mkdirs()
                    file.writeText(content)
                    "Successfully wrote ${content.length} chars to $path"
                }

                "execute_command" -> {
                    val command = input.get("command").asString
                    val timeout = input.get("timeout")?.asLong ?: 30L
                    executeShellCommand(command, timeout)
                }

                "list_directory" -> {
                    val path = resolvePath(input.get("path").asString)
                    val recursive = input.get("recursive")?.asBoolean ?: false
                    listDirectory(path, recursive)
                }

                "search_files" -> {
                    val pattern = input.get("pattern").asString
                    val directory = resolvePath(input.get("directory").asString)
                    val filePattern = input.get("file_pattern")?.asString ?: "*"
                    searchFiles(pattern, directory, filePattern)
                }

                "delete_file" -> {
                    val path = resolvePath(input.get("path").asString)
                    val file = File(path)
                    if (!file.exists()) "Error: Path not found: $path"
                    else {
                        file.deleteRecursively()
                        "Deleted: $path"
                    }
                }

                "create_directory" -> {
                    val path = resolvePath(input.get("path").asString)
                    File(path).mkdirs()
                    "Created directory: $path"
                }

                "move_file" -> {
                    val source = resolvePath(input.get("source").asString)
                    val dest = resolvePath(input.get("destination").asString)
                    val srcFile = File(source)
                    val destFile = File(dest)
                    destFile.parentFile?.mkdirs()
                    if (srcFile.renameTo(destFile)) "Moved $source → $dest"
                    else "Error: Could not move file"
                }

                "web_fetch" -> {
                    val url = input.get("url").asString
                    fetchUrl(url)
                }

                "find_replace" -> {
                    val path = resolvePath(input.get("path").asString)
                    val find = input.get("find").asString
                    val replace = input.get("replace").asString
                    val file = File(path)
                    if (!file.exists()) "Error: File not found"
                    else {
                        val content = file.readText()
                        val count = content.split(find).size - 1
                        file.writeText(content.replace(find, replace))
                        "Replaced $count occurrence(s) in $path"
                    }
                }

                else -> "Error: Unknown tool: $name"
            }
        } catch (e: Exception) {
            "Error executing $name: ${e.message}"
        }
    }

    private fun resolvePath(path: String): String {
        return if (path.startsWith("/")) path
        else "$projectRoot/$path"
    }

    private suspend fun executeShellCommand(command: String, timeoutSecs: Long): String {
        return try {
            val process = ProcessBuilder("/bin/sh", "-c", command)
                .directory(File(projectRoot))
                .redirectErrorStream(true)
                .start()

            val output = StringBuilder()
            val reader = process.inputStream.bufferedReader()
            val finished = process.waitFor(timeoutSecs, java.util.concurrent.TimeUnit.SECONDS)

            if (!finished) {
                process.destroy()
                return "Error: Command timed out after ${timeoutSecs}s"
            }

            output.append(reader.readText())
            val exitCode = process.exitValue()
            if (exitCode != 0) "Exit code $exitCode:\n${output.toString().take(5000)}"
            else output.toString().take(5000).ifEmpty { "Command completed successfully" }
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }

    private fun listDirectory(path: String, recursive: Boolean): String {
        val dir = File(path)
        if (!dir.exists()) return "Error: Directory not found: $path"
        if (!dir.isDirectory) return "Error: Not a directory: $path"

        val sb = StringBuilder()
        fun walk(file: File, indent: String = "") {
            if (file.isDirectory) {
                sb.appendLine("$indent📁 ${file.name}/")
                if (recursive) {
                    file.listFiles()?.sortedWith(compareBy({ !it.isDirectory }, { it.name }))
                        ?.forEach { walk(it, "$indent  ") }
                }
            } else {
                val size = when {
                    file.length() > 1_000_000 -> "${file.length() / 1_000_000}MB"
                    file.length() > 1_000 -> "${file.length() / 1_000}KB"
                    else -> "${file.length()}B"
                }
                sb.appendLine("$indent📄 ${file.name} ($size)")
            }
        }

        dir.listFiles()?.sortedWith(compareBy({ !it.isDirectory }, { it.name }))
            ?.forEach { walk(it) }

        return sb.toString().ifEmpty { "Empty directory" }
    }

    private fun searchFiles(pattern: String, directory: String, filePattern: String): String {
        val dir = File(directory)
        if (!dir.exists()) return "Error: Directory not found"

        val results = StringBuilder()
        var matchCount = 0

        dir.walkTopDown()
            .filter { it.isFile }
            .filter { filePattern == "*" || it.name.matches(filePattern.replace("*", ".*").toRegex()) }
            .take(100) // limit files searched
            .forEach { file ->
                try {
                    val lines = file.readLines()
                    lines.forEachIndexed { index, line ->
                        if (line.contains(pattern, ignoreCase = false)) {
                            results.appendLine("${file.path}:${index + 1}: $line")
                            matchCount++
                            if (matchCount >= 50) return "Found 50+ matches, showing first 50:\n$results"
                        }
                    }
                } catch (_: Exception) {}
            }

        return if (matchCount == 0) "No matches found for '$pattern'"
        else "Found $matchCount matches:\n$results"
    }

    private suspend fun fetchUrl(url: String): String {
        return try {
            val client = okhttp3.OkHttpClient.Builder()
                .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                .build()

            val request = okhttp3.Request.Builder()
                .url(url)
                .addHeader("User-Agent", "TabAgent/1.0")
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: "Empty response"

            // Basic HTML stripping
            body.replace(Regex("<[^>]+>"), " ")
                .replace(Regex("\\s+"), " ")
                .trim()
                .take(8000)
        } catch (e: Exception) {
            "Error fetching URL: ${e.message}"
        }
    }
}
