package com.tabagent.ui.screens

import android.view.ViewGroup
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import io.github.rosemoe.sora.widget.CodeEditor
import io.github.rosemoe.sora.langs.textmate.TextMateLanguage
import io.github.rosemoe.sora.langs.textmate.registry.ThemeRegistry
import io.github.rosemoe.sora.langs.textmate.registry.FileProviderRegistry
import io.github.rosemoe.sora.langs.textmate.registry.GrammarRegistry
import io.github.rosemoe.sora.text.Content
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    filePath: String,
    onBack: () -> Unit,
    onSave: (String) -> Unit = {}
) {
    val context = LocalContext.current
    var content by remember { mutableStateOf("") }
    var isSaved by remember { mutableStateOf(true) }
    var editorRef by remember { mutableStateOf<CodeEditor?>(null) }

    // Load file content
    LaunchedEffect(filePath) {
        content = try { File(filePath).readText() } catch (e: Exception) { "" }
    }

    val fileName = filePath.split("/").last()
    val fileExt = fileName.substringAfterLast(".").lowercase()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(fileName, style = MaterialTheme.typography.titleSmall)
                        if (!isSaved) {
                            Text("Unsaved changes",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.error)
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Undo
                    IconButton(onClick = { editorRef?.undo() }) {
                        Icon(Icons.Default.Undo, contentDescription = "Undo")
                    }
                    // Redo
                    IconButton(onClick = { editorRef?.redo() }) {
                        Icon(Icons.Default.Redo, contentDescription = "Redo")
                    }
                    // Save
                    IconButton(onClick = {
                        val text = editorRef?.text?.toString() ?: content
                        try {
                            File(filePath).writeText(text)
                            isSaved = true
                            onSave(text)
                        } catch (_: Exception) {}
                    }) {
                        Icon(
                            Icons.Default.Save,
                            contentDescription = "Save",
                            tint = if (isSaved) LocalContentColor.current
                                   else MaterialTheme.colorScheme.primary
                        )
                    }
                }
            )
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            AndroidView(
                factory = { ctx ->
                    CodeEditor(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        setText(content)
                        isWordwrap = true
                        setTextSize(14f)
                        isLineNumberEnabled = true
                        isHighlightCurrentLine = true

                        // Try to set language based on extension
                        try {
                            setEditorLanguage(
                                TextMateLanguage.create(
                                    when (fileExt) {
                                        "py" -> "source.python"
                                        "js", "ts" -> "source.js"
                                        "kt" -> "source.kotlin"
                                        "java" -> "source.java"
                                        "html" -> "text.html.basic"
                                        "css" -> "source.css"
                                        "json" -> "source.json"
                                        "sh", "bash" -> "source.shell"
                                        "xml" -> "text.xml"
                                        "md" -> "text.html.markdown"
                                        "c", "h" -> "source.c"
                                        "cpp" -> "source.cpp"
                                        "rs" -> "source.rust"
                                        "go" -> "source.go"
                                        "rb" -> "source.ruby"
                                        "php" -> "text.html.php"
                                        "swift" -> "source.swift"
                                        "dart" -> "source.dart"
                                        else -> "text.plain"
                                    }, true
                                )
                            )
                        } catch (_: Exception) {}

                        editorRef = this
                    }
                },
                update = { editor ->
                    // Monitor changes
                    editor.setOnContentChangeListener { _, _, _ ->
                        isSaved = false
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}
