package com.tabagent.network

import com.tabagent.model.ApiConfig
import com.tabagent.model.ApiProvider
import com.tabagent.model.ChatMessage
import com.tabagent.model.MessageRole
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.JsonArray
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.BufferedReader
import java.io.InputStreamReader

class AiApiClient(private val config: ApiConfig) {

    private val gson = Gson()
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(300, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    // Stream a response token by token
    fun streamResponse(
        messages: List<ChatMessage>,
        tools: List<ToolDefinition> = emptyList()
    ): Flow<StreamEvent> = flow {
        val request = buildRequest(messages, tools, stream = true)
        val call = client.newCall(request)

        try {
            val response = call.execute()
            if (!response.isSuccessful) {
                val errorBody = response.body?.string() ?: "Unknown error"
                emit(StreamEvent.Error("API error ${response.code}: $errorBody"))
                return@flow
            }

            val reader = BufferedReader(InputStreamReader(response.body!!.byteStream()))
            var line: String?
            var currentToolId: String? = null
            var currentToolName: String? = null
            var currentToolInput = StringBuilder()
            var inputAccumulator = StringBuilder()

            while (reader.readLine().also { line = it } != null) {
                val l = line ?: continue
                if (l.isEmpty() || l == "data: [DONE]") continue

                val data = when {
                    l.startsWith("data: ") -> l.removePrefix("data: ")
                    else -> continue
                }

                try {
                    val json = gson.fromJson(data, JsonObject::class.java)
                    when (config.provider) {
                        ApiProvider.ANTHROPIC -> parseAnthropicEvent(
                            json, currentToolId, currentToolName,
                            currentToolInput, inputAccumulator
                        ) { event, tId, tName, tInput, accum ->
                            currentToolId = tId
                            currentToolName = tName
                            currentToolInput = tInput
                            inputAccumulator = accum
                            emit(event)
                        }
                        else -> parseOpenAiEvent(json) { emit(it) }
                    }
                } catch (_: Exception) {}
            }

            emit(StreamEvent.Done)

        } catch (e: Exception) {
            emit(StreamEvent.Error(e.message ?: "Network error"))
        }
    }

    // Non-streaming response
    suspend fun complete(messages: List<ChatMessage>): String {
        val request = buildRequest(messages, stream = false)
        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: return "Error: empty response"

        return try {
            val json = gson.fromJson(body, JsonObject::class.java)
            when (config.provider) {
                ApiProvider.ANTHROPIC -> {
                    json.getAsJsonArray("content")
                        ?.firstOrNull { it.asJsonObject.get("type")?.asString == "text" }
                        ?.asJsonObject?.get("text")?.asString ?: "No response"
                }
                else -> {
                    json.getAsJsonArray("choices")
                        ?.firstOrNull()?.asJsonObject
                        ?.getAsJsonObject("message")
                        ?.get("content")?.asString ?: "No response"
                }
            }
        } catch (e: Exception) {
            "Parse error: ${e.message}"
        }
    }

    private fun buildRequest(
        messages: List<ChatMessage>,
        tools: List<ToolDefinition> = emptyList(),
        stream: Boolean
    ): Request {
        val body = buildRequestBody(messages, tools, stream)
        val url = when (config.provider) {
            ApiProvider.ANTHROPIC -> "${config.baseUrl}/v1/messages"
            ApiProvider.GROQ -> "${config.baseUrl}/v1/chat/completions"
            ApiProvider.CUSTOM -> "${config.baseUrl}/v1/chat/completions"
            else -> "${config.baseUrl}/v1/chat/completions"
        }

        return Request.Builder()
            .url(url)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .apply {
                when (config.provider) {
                    ApiProvider.ANTHROPIC -> {
                        addHeader("x-api-key", config.apiKey)
                        addHeader("anthropic-version", "2023-06-01")
                        addHeader("anthropic-beta", "tools-2024-04-04")
                    }
                    else -> addHeader("Authorization", "Bearer ${config.apiKey}")
                }
                addHeader("Content-Type", "application/json")
            }
            .build()
    }

    private fun buildRequestBody(
        messages: List<ChatMessage>,
        tools: List<ToolDefinition>,
        stream: Boolean
    ): JsonObject = JsonObject().apply {
        addProperty("model", config.model)
        addProperty("stream", stream)
        addProperty("max_tokens", config.maxTokens)
        addProperty("temperature", config.temperature.toDouble())

        when (config.provider) {
            ApiProvider.ANTHROPIC -> {
                // System message separate
                val systemMsg = messages.firstOrNull { it.role == MessageRole.SYSTEM }
                if (systemMsg != null) {
                    addProperty("system", systemMsg.content)
                } else {
                    addProperty("system", config.systemPrompt)
                }

                // Messages array (exclude system)
                val msgArray = JsonArray()
                messages.filter { it.role != MessageRole.SYSTEM }.forEach { msg ->
                    msgArray.add(JsonObject().apply {
                        addProperty("role", if (msg.role == MessageRole.ASSISTANT) "assistant" else "user")
                        addProperty("content", msg.content)
                    })
                }
                add("messages", msgArray)

                // Tools
                if (tools.isNotEmpty()) {
                    add("tools", buildAnthropicTools(tools))
                }
            }
            else -> {
                // OpenAI-compatible
                val msgArray = JsonArray()

                // Add system prompt
                msgArray.add(JsonObject().apply {
                    addProperty("role", "system")
                    addProperty("content", config.systemPrompt)
                })

                messages.filter { it.role != MessageRole.SYSTEM }.forEach { msg ->
                    msgArray.add(JsonObject().apply {
                        addProperty("role", when (msg.role) {
                            MessageRole.ASSISTANT -> "assistant"
                            MessageRole.TOOL -> "tool"
                            else -> "user"
                        })
                        addProperty("content", msg.content)
                    })
                }
                add("messages", msgArray)

                if (tools.isNotEmpty()) {
                    add("tools", buildOpenAiTools(tools))
                }
            }
        }
    }

    private fun buildAnthropicTools(tools: List<ToolDefinition>): JsonArray = JsonArray().also { arr ->
        tools.forEach { tool ->
            arr.add(JsonObject().apply {
                addProperty("name", tool.name)
                addProperty("description", tool.description)
                add("input_schema", JsonObject().apply {
                    addProperty("type", "object")
                    val props = JsonObject()
                    tool.parameters.forEach { param ->
                        props.add(param.name, JsonObject().apply {
                            addProperty("type", param.type)
                            addProperty("description", param.description)
                        })
                    }
                    add("properties", props)
                    val required = JsonArray()
                    tool.parameters.filter { it.required }.forEach { required.add(it.name) }
                    add("required", required)
                })
            })
        }
    }

    private fun buildOpenAiTools(tools: List<ToolDefinition>): JsonArray = JsonArray().also { arr ->
        tools.forEach { tool ->
            arr.add(JsonObject().apply {
                addProperty("type", "function")
                add("function", JsonObject().apply {
                    addProperty("name", tool.name)
                    addProperty("description", tool.description)
                    add("parameters", JsonObject().apply {
                        addProperty("type", "object")
                        val props = JsonObject()
                        tool.parameters.forEach { param ->
                            props.add(param.name, JsonObject().apply {
                                addProperty("type", param.type)
                                addProperty("description", param.description)
                            })
                        }
                        add("properties", props)
                        val required = JsonArray()
                        tool.parameters.filter { it.required }.forEach { required.add(it.name) }
                        add("required", required)
                    })
                })
            })
        }
    }

    private suspend fun parseAnthropicEvent(
        json: JsonObject,
        toolId: String?,
        toolName: String?,
        toolInput: StringBuilder,
        accumulator: StringBuilder,
        callback: suspend (StreamEvent, String?, String?, StringBuilder, StringBuilder) -> Unit
    ) {
        var tId = toolId
        var tName = toolName
        val tInput = toolInput

        when (json.get("type")?.asString) {
            "content_block_start" -> {
                val block = json.getAsJsonObject("content_block")
                if (block?.get("type")?.asString == "tool_use") {
                    tId = block.get("id")?.asString
                    tName = block.get("name")?.asString
                    tInput.clear()
                }
            }
            "content_block_delta" -> {
                val delta = json.getAsJsonObject("delta") ?: return
                when (delta.get("type")?.asString) {
                    "text_delta" -> {
                        val text = delta.get("text")?.asString ?: return
                        accumulator.append(text)
                        callback(StreamEvent.Token(text), tId, tName, tInput, accumulator)
                        return
                    }
                    "input_json_delta" -> {
                        val partial = delta.get("partial_json")?.asString ?: ""
                        tInput.append(partial)
                    }
                    "thinking_delta" -> {
                        val thinking = delta.get("thinking")?.asString ?: ""
                        callback(StreamEvent.Thinking(thinking), tId, tName, tInput, accumulator)
                        return
                    }
                }
            }
            "content_block_stop" -> {
                if (tId != null && tName != null) {
                    callback(
                        StreamEvent.ToolUse(tId, tName, tInput.toString()),
                        null, null, StringBuilder(), accumulator
                    )
                    return
                }
            }
            "message_stop" -> {
                callback(StreamEvent.Done, null, null, StringBuilder(), accumulator)
                return
            }
        }
        callback(StreamEvent.Nothing, tId, tName, tInput, accumulator)
    }

    private suspend fun parseOpenAiEvent(json: JsonObject, emit: suspend (StreamEvent) -> Unit) {
        val choices = json.getAsJsonArray("choices") ?: return
        val choice = choices.firstOrNull()?.asJsonObject ?: return
        val delta = choice.getAsJsonObject("delta") ?: return
        val content = delta.get("content")?.asString

        if (content != null) {
            emit(StreamEvent.Token(content))
        }

        val finishReason = choice.get("finish_reason")?.asString
        if (finishReason == "stop") emit(StreamEvent.Done)
    }
}

// ─── Stream Events ────────────────────────────────────────────────────────────

sealed class StreamEvent {
    data class Token(val text: String) : StreamEvent()
    data class Thinking(val text: String) : StreamEvent()
    data class ToolUse(val id: String, val name: String, val input: String) : StreamEvent()
    data class ToolResult(val id: String, val result: String) : StreamEvent()
    data class Error(val message: String) : StreamEvent()
    object Done : StreamEvent()
    object Nothing : StreamEvent()
}

// ─── Tool Definitions ─────────────────────────────────────────────────────────

data class ToolDefinition(
    val name: String,
    val description: String,
    val parameters: List<ToolParameter>
)

data class ToolParameter(
    val name: String,
    val type: String,
    val description: String,
    val required: Boolean = true
)
