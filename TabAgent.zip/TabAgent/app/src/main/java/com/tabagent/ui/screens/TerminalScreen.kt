package com.tabagent.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.tabagent.viewmodel.TerminalViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TerminalScreen(
    viewModel: TerminalViewModel = hiltViewModel(),
    onBack: () -> Unit
) {
    val outputLines by viewModel.outputLines.collectAsState()
    val currentDir by viewModel.currentDir.collectAsState()
    val isRunning by viewModel.isRunning.collectAsState()
    var input by remember { mutableStateOf(TextFieldValue("")) }
    val listState = rememberLazyListState()
    val focusRequester = remember { FocusRequester() }
    val history by viewModel.commandHistory.collectAsState()
    var historyIndex by remember { mutableStateOf(-1) }

    LaunchedEffect(outputLines.size) {
        if (outputLines.isNotEmpty()) {
            listState.animateScrollToItem(outputLines.size - 1)
        }
    }

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Terminal — ${currentDir.split("/").lastOrNull() ?: "/"}",
                        fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.titleSmall
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (isRunning) {
                        IconButton(onClick = { viewModel.killCurrentProcess() }) {
                            Icon(Icons.Default.Stop, contentDescription = "Kill",
                                tint = MaterialTheme.colorScheme.error)
                        }
                    }
                    IconButton(onClick = { viewModel.clearScreen() }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1A1A2E)
                )
            )
        },
        containerColor = Color(0xFF0D0D0D)
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            // Output
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(outputLines) { line ->
                    Text(
                        text = line.text,
                        color = when (line.type) {
                            LineType.COMMAND -> Color(0xFF4FC3F7)
                            LineType.OUTPUT -> Color(0xFFE0E0E0)
                            LineType.ERROR -> Color(0xFFEF5350)
                            LineType.SYSTEM -> Color(0xFF66BB6A)
                        },
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }
            }

            // Input row
            Surface(color = Color(0xFF1A1A1A)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .imePadding()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "$ ",
                        color = Color(0xFF66BB6A),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp
                    )

                    BasicTextField(
                        value = input,
                        onValueChange = {
                            input = it
                            historyIndex = -1
                        },
                        textStyle = TextStyle(
                            color = Color(0xFFE0E0E0),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .focusRequester(focusRequester)
                    )

                    // History navigation
                    if (history.isNotEmpty()) {
                        IconButton(
                            onClick = {
                                historyIndex = (historyIndex + 1).coerceAtMost(history.size - 1)
                                input = TextFieldValue(history[historyIndex])
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.ArrowUpward, contentDescription = "History up",
                                tint = Color.Gray, modifier = Modifier.size(16.dp))
                        }
                    }

                    IconButton(
                        onClick = {
                            val cmd = input.text.trim()
                            if (cmd.isNotBlank()) {
                                viewModel.executeCommand(cmd)
                                input = TextFieldValue("")
                                historyIndex = -1
                            }
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            Icons.Default.Send,
                            contentDescription = "Run",
                            tint = if (input.text.isNotBlank()) Color(0xFF4FC3F7) else Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Quick command bar
            QuickCommandBar(
                onCommand = { cmd ->
                    input = TextFieldValue(cmd)
                    focusRequester.requestFocus()
                }
            )
        }
    }
}

@Composable
fun QuickCommandBar(onCommand: (String) -> Unit) {
    val quickCommands = listOf("ls", "pwd", "cd ..", "clear", "python3", "node", "git status")

    Surface(color = Color(0xFF111111)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            quickCommands.forEach { cmd ->
                SuggestionChip(
                    onClick = { onCommand(cmd) },
                    label = {
                        Text(cmd, fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp, color = Color(0xFF90CAF9))
                    },
                    colors = SuggestionChipDefaults.suggestionChipColors(
                        containerColor = Color(0xFF1E2A3A)
                    ),
                    border = SuggestionChipDefaults.suggestionChipBorder(
                        enabled = true,
                        borderColor = Color(0xFF2A3A4A)
                    )
                )
            }
        }
    }
}

data class TerminalLine(val text: String, val type: LineType)
enum class LineType { COMMAND, OUTPUT, ERROR, SYSTEM }
