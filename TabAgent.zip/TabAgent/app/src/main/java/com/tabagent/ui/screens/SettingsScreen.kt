package com.tabagent.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.tabagent.model.*
import com.tabagent.viewmodel.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = hiltViewModel(),
    onBack: () -> Unit
) {
    val config by viewModel.apiConfig.collectAsState()
    val settings by viewModel.appSettings.collectAsState()
    var showApiKey by remember { mutableStateOf(false) }
    var tempApiKey by remember(config.apiKey) { mutableStateOf(config.apiKey) }
    var tempBaseUrl by remember(config.baseUrl) { mutableStateOf(config.baseUrl) }
    var tempModel by remember(config.model) { mutableStateOf(config.model) }
    var tempSystemPrompt by remember(config.systemPrompt) { mutableStateOf(config.systemPrompt) }
    var expanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    TextButton(onClick = {
                        viewModel.saveApiConfig(
                            config.copy(
                                apiKey = tempApiKey,
                                baseUrl = tempBaseUrl.ifBlank { config.provider.baseUrl },
                                model = tempModel,
                                systemPrompt = tempSystemPrompt
                            )
                        )
                        onBack()
                    }) {
                        Text("Save")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ─── Provider Section ──────────────────────────────────────────────
            item {
                SectionHeader("AI Provider")
            }

            item {
                // Provider dropdown
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = it }
                ) {
                    OutlinedTextField(
                        value = config.provider.displayName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Provider") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        ApiProvider.entries.forEach { provider ->
                            DropdownMenuItem(
                                text = { Text(provider.displayName) },
                                onClick = {
                                    viewModel.saveApiConfig(config.copy(
                                        provider = provider,
                                        baseUrl = provider.baseUrl,
                                        model = when (provider) {
                                            ApiProvider.ANTHROPIC -> "claude-sonnet-4-6"
                                            ApiProvider.OPENAI -> "gpt-4o"
                                            ApiProvider.GROQ -> "llama-3.3-70b-versatile"
                                            ApiProvider.OPENROUTER -> "anthropic/claude-sonnet-4-6"
                                            ApiProvider.CUSTOM -> "local-model"
                                        }
                                    ))
                                    tempModel = when (provider) {
                                        ApiProvider.ANTHROPIC -> "claude-sonnet-4-6"
                                        ApiProvider.OPENAI -> "gpt-4o"
                                        ApiProvider.GROQ -> "llama-3.3-70b-versatile"
                                        ApiProvider.OPENROUTER -> "anthropic/claude-sonnet-4-6"
                                        ApiProvider.CUSTOM -> "local-model"
                                    }
                                    tempBaseUrl = provider.baseUrl
                                    expanded = false
                                }
                            )
                        }
                    }
                }
            }

            item {
                // API Key field
                OutlinedTextField(
                    value = tempApiKey,
                    onValueChange = { tempApiKey = it },
                    label = { Text("API Key") },
                    placeholder = { Text("sk-ant-... or sk-...") },
                    visualTransformation = if (showApiKey) VisualTransformation.None
                                          else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        IconButton(onClick = { showApiKey = !showApiKey }) {
                            Icon(
                                if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "Toggle visibility"
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    supportingText = {
                        when (config.provider) {
                            ApiProvider.ANTHROPIC -> Text("Get from console.anthropic.com")
                            ApiProvider.OPENAI -> Text("Get from platform.openai.com")
                            ApiProvider.GROQ -> Text("Get from console.groq.com (Free tier available)")
                            ApiProvider.OPENROUTER -> Text("Get from openrouter.ai")
                            ApiProvider.CUSTOM -> Text("Your local server API key (or leave blank)")
                        }
                    }
                )
            }

            item {
                // Model
                OutlinedTextField(
                    value = tempModel,
                    onValueChange = { tempModel = it },
                    label = { Text("Model") },
                    modifier = Modifier.fillMaxWidth(),
                    supportingText = {
                        when (config.provider) {
                            ApiProvider.ANTHROPIC -> Text("claude-opus-4-6, claude-sonnet-4-6, claude-haiku-5-5")
                            ApiProvider.OPENAI -> Text("gpt-4o, gpt-4o-mini, gpt-4-turbo")
                            ApiProvider.GROQ -> Text("llama-3.3-70b-versatile, mixtral-8x7b-32768")
                            else -> Text("Enter model name")
                        }
                    }
                )
            }

            // Custom base URL for Custom provider
            if (config.provider == ApiProvider.CUSTOM) {
                item {
                    OutlinedTextField(
                        value = tempBaseUrl,
                        onValueChange = { tempBaseUrl = it },
                        label = { Text("Base URL") },
                        placeholder = { Text("http://192.168.1.100:1234") },
                        modifier = Modifier.fillMaxWidth(),
                        supportingText = { Text("Your local LLM server (Ollama, LM Studio, etc.)") }
                    )
                }
            }

            // ─── Model Parameters ──────────────────────────────────────────────
            item { SectionHeader("Model Parameters") }

            item {
                Column {
                    Text("Max Tokens: ${config.maxTokens}",
                        style = MaterialTheme.typography.bodyMedium)
                    Slider(
                        value = config.maxTokens.toFloat(),
                        onValueChange = {
                            viewModel.saveApiConfig(config.copy(maxTokens = it.toInt()))
                        },
                        valueRange = 1024f..32768f,
                        steps = 15
                    )
                }
            }

            item {
                Column {
                    Text("Temperature: ${"%.1f".format(config.temperature)}",
                        style = MaterialTheme.typography.bodyMedium)
                    Slider(
                        value = config.temperature,
                        onValueChange = {
                            viewModel.saveApiConfig(config.copy(temperature = it))
                        },
                        valueRange = 0f..1f
                    )
                }
            }

            // ─── System Prompt ─────────────────────────────────────────────────
            item { SectionHeader("System Prompt") }

            item {
                OutlinedTextField(
                    value = tempSystemPrompt,
                    onValueChange = { tempSystemPrompt = it },
                    label = { Text("System Prompt") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4,
                    maxLines = 10
                )
            }

            // ─── App Settings ──────────────────────────────────────────────────
            item { SectionHeader("App Settings") }

            item {
                // Theme
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Theme", style = MaterialTheme.typography.bodyLarge)
                    SegmentedButtonRow {
                        AppTheme.entries.forEachIndexed { index, theme ->
                            SegmentedButton(
                                selected = settings.theme == theme,
                                onClick = { viewModel.saveSettings(settings.copy(theme = theme)) },
                                shape = SegmentedButtonDefaults.itemShape(index, AppTheme.entries.size)
                            ) {
                                Text(theme.name.lowercase().replaceFirstChar { it.uppercase() })
                            }
                        }
                    }
                }
            }

            item {
                SettingsSwitch(
                    title = "Streaming responses",
                    subtitle = "Show text as it's generated",
                    checked = settings.streamingEnabled,
                    onCheckedChange = { viewModel.saveSettings(settings.copy(streamingEnabled = it)) }
                )
            }

            item {
                SettingsSwitch(
                    title = "Show token count",
                    subtitle = "Display token usage in header",
                    checked = settings.showTokenCount,
                    onCheckedChange = { viewModel.saveSettings(settings.copy(showTokenCount = it)) }
                )
            }

            item {
                SettingsSwitch(
                    title = "Show thinking",
                    subtitle = "Display model's reasoning (if supported)",
                    checked = settings.showThinking,
                    onCheckedChange = { viewModel.saveSettings(settings.copy(showThinking = it)) }
                )
            }

            item {
                SettingsSwitch(
                    title = "Haptic feedback",
                    checked = settings.hapticFeedback,
                    onCheckedChange = { viewModel.saveSettings(settings.copy(hapticFeedback = it)) }
                )
            }

            item {
                Column {
                    Text("Editor font size: ${settings.fontSize}sp",
                        style = MaterialTheme.typography.bodyMedium)
                    Slider(
                        value = settings.fontSize.toFloat(),
                        onValueChange = { viewModel.saveSettings(settings.copy(fontSize = it.toInt())) },
                        valueRange = 10f..24f,
                        steps = 13
                    )
                }
            }

            item { Spacer(Modifier.height(32.dp)) }
        }
    }
}

@Composable
fun SectionHeader(title: String) {
    Text(
        title,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 8.dp)
    )
    HorizontalDivider()
}

@Composable
fun SettingsSwitch(
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            subtitle?.let {
                Text(it, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
