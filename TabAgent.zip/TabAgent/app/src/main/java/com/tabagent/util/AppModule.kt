package com.tabagent.util

import android.content.Context
import androidx.room.Room
import com.tabagent.model.TabAgentDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): TabAgentDatabase {
        return Room.databaseBuilder(
            context,
            TabAgentDatabase::class.java,
            "tabagent_db"
        ).fallbackToDestructiveMigration().build()
    }

    @Provides
    fun provideSessionDao(db: TabAgentDatabase) = db.sessionDao()

    @Provides
    fun provideMessageDao(db: TabAgentDatabase) = db.messageDao()

    @Provides
    fun provideProjectDao(db: TabAgentDatabase) = db.projectDao()
}
