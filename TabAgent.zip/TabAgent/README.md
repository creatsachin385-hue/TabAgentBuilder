# TabAgent — AI Coding Agent for Galaxy Tab A7 Lite

Mobile Harness / AnyClaw जैसा app — Galaxy Tab A7 Lite के लिए।

## Features

| Feature | Details |
|---|---|
| 🤖 AI Chat | Claude, GPT-4, Groq, OpenRouter, Custom LLM |
| 🔧 Agentic Tools | read_file, write_file, execute_command, search_files, web_fetch, +5 more |
| 📁 File Browser | Create, edit, preview, delete files |
| 💻 Terminal | Real shell, command history, quick buttons |
| ✏️ Code Editor | Syntax highlight (20+ languages), undo/redo |
| 🔐 Secure Keys | API keys stored in Android Keystore (encrypted) |
| 🌙 Dark Theme | Dark/Light/System |
| 📱 Tablet Layout | Split panel for tablet screens |

## Setup

### 1. Android Studio में open करो
```
File → Open → TabAgent folder select करो
```

### 2. Gradle sync होने दो

### 3. Galaxy Tab A7 Lite पर install करो
```
Run → Run 'app'
```
USB debugging on होना चाहिए:
- Settings → About tablet → Build number 7 बार tap
- Settings → Developer options → USB debugging ON

### 4. App open करो → Settings → API key डालो

## Supported Providers

| Provider | Model Examples | Cost |
|---|---|---|
| Anthropic | claude-sonnet-4-6, claude-haiku-5-5 | Paid |
| OpenAI | gpt-4o, gpt-4o-mini | Paid |
| **Groq** | llama-3.3-70b-versatile | **Free tier** ✅ |
| OpenRouter | 100+ models | Pay-per-use |
| Custom | Ollama, LM Studio | Local/Free |

> **Free शुरू करना है?** Groq पर जाओ: https://console.groq.com
> Free account बनाओ, API key मिलेगी — काफी fast है।

## Project Structure

```
TabAgent/
├── app/src/main/java/com/tabagent/
│   ├── agent/
│   │   └── AgentExecutor.kt      ← Tool execution (file/shell/web)
│   ├── model/
│   │   ├── Models.kt             ← Data classes
│   │   └── Database.kt           ← Room DB
│   ├── network/
│   │   └── AiApiClient.kt        ← Streaming API client
│   ├── ui/
│   │   ├── MainActivity.kt       ← Navigation
│   │   └── screens/
│   │       ├── ChatScreen.kt     ← Main chat + agent UI
│   │       ├── SettingsScreen.kt ← API key + settings
│   │       ├── FileBrowserScreen.kt
│   │       ├── TerminalScreen.kt
│   │       └── EditorScreen.kt   ← Code editor
│   ├── viewmodel/
│   │   ├── ChatViewModel.kt      ← Agent loop logic
│   │   ├── TerminalViewModel.kt
│   │   └── OtherViewModels.kt
│   └── util/
│       ├── SecurePrefs.kt        ← Encrypted key storage
│       └── AppModule.kt          ← Hilt DI
```

## Agentic Loop

```
User message
    ↓
AI responds + optionally calls a tool (read_file, execute_command, etc.)
    ↓
AgentExecutor runs the tool
    ↓
Result sent back to AI
    ↓
AI responds again (may call more tools)
    ↓
Loop continues until AI gives final answer (max 20 iterations)
```

## Example Usage

```
"Create a Python script that downloads all images from a URL"
→ Agent writes the script, runs it, shows output

"Build a simple web server in Node.js and start it"
→ Agent creates server.js, runs npm install, starts server

"Read my project structure and explain what each file does"  
→ Agent reads all files, gives summary
```

## Galaxy Tab A7 Lite Notes

- Minimum Android 7.0 (API 24) — Tab A7 Lite runs Android 11
- ARM64 architecture — সব commands work
- `/data/data/com.tabagent/files/` — app का working directory
- Large RAM না होने की वजह से max_tokens 4096 रखना better है
